﻿using System;
using System.Collections.Generic;

namespace JoshuaH_301186067_A2
{
    public enum Region { East, West }  
}
