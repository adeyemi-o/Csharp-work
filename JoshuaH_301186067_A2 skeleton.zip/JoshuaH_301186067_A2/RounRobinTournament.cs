﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoshuaH_301186067_A2
{
    public class RounRobinTournament : Tournament
    {
        // NOTE: Must impliment the tournament base class methods.
        // Methods:
        // RounRobinTournament(string name)
        // SetMatches() : void
    }
}
