﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoshuaH_301186067_A2
{
    public class KnockoutTournament : Tournament
    {
        // NOTE: Must impliment the tournament base class methods.
        // Fields:
        // availableTeams : List<Team>
        // noOfMatches : int
        // random : Random

        // Methods:
        // AddWinner(Team winner, Team loser) : void
        // KnockoutTournament(string name)
        // SetMatches() : void
    }
}
