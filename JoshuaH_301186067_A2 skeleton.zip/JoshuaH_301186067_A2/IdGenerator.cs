﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoshuaH_301186067_A2
{
    public static class IdGenerator
    {
        // Fields:
        // nextId : uint
        // Methods:
        // GetId() : uint
    }
}
