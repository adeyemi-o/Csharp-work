﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoshuaH_301186067_A2
{
    public class Match
    {
        // Fields:
        // finished : bool
        // teams : Team[]
        // winningTeam : Team

        // Properties:
        // Finished { get; } : bool
        // MatchNumber { get; set; } : int
        // Teams { get; } : Team[]
        // WinningTeam { get; set; } : Team

        // Methods:
        // Match(int number, Team team1, Team team2)
        // ToString() : string
    }
}
