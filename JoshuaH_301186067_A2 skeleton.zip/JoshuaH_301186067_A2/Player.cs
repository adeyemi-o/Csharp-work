﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoshuaH_301186067_A2
{
    public class Player
    {
        // Properties:
        // Date of Birth {get; set;} : DateTime
        // Id {get;} : uint
        // Name {get; set;} : string

        // Methods:
        // Player()
        // Player(string name, DateTime dob)
        // Player(string name, DateTime dob, Team team)
        // ToString() : string
    }
}
