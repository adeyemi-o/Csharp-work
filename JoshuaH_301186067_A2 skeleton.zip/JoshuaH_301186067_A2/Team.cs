﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoshuaH_301186067_A2
{
    public class Team
    {
        // Fields:
        // players : List<Player>

        // Properties:
        // Id { get; } : uint
        // Name { get; set; } : string
        // Players { get; set; } : List<Player>
        // Region { get; set; } : Region

        // Methods:
        // AddPlayer(Player aPlayer) : void
        // FindPlayer(uint id) : Player
        // GetPlayers(string name) : IEnumerable<Player>
        // Team()
        // Team(string name)
        // Team(string name, Region region)
        // ToString() : string
    }
}
